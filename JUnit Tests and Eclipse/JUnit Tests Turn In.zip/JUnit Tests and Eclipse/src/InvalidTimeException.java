/**
 * Auto generated custom Exception Useful for the Time class
 * 
 * @author Brian Hauck
 *
 */
public class InvalidTimeException extends RuntimeException {

	public InvalidTimeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
